# Metro Vitals Medical website

A single-page, responsive clinic website concept for `metrovitals.com`.

## Included
- Responsive homepage with mobile navigation
- Mauve/pastel palette, white, dark grey and restrained dull-red accents
- Hero section and clear appointment CTAs
- Services, dedicated pharmacy section, clinic story, patient-experience section and contact area
- Appointment request form front-end (demo only)
- No external JavaScript dependencies

## Before launch
Replace the placeholder phone number, address, opening hours and any copy that needs to reflect the clinic's real services. Connect the appointment form to the clinic's actual email/booking backend and add verified privacy/terms language.

## Run locally
Open `index.html` directly in a browser, or serve the folder with any static web server.
