# Metro Vitals Medical - Brand Kit

A cohesive identity system for Metro Vitals Medical, a city clinic that grew from a pharmacy and continues to operate an integrated pharmacy.

## Included
- Primary, reversed and icon logo marks
- Business card
- A4 letterhead
- Prescription / clinical pad
- DL envelope
- Pharmacy / retail bag
- Notebook / branded book cover
- Vehicle livery
- Ambulance livery
- 4 social advertisement concepts
- Instagram story poster
- Email signature
- Brand guidelines PDF

Contact details shown in the artwork are intentionally placeholders until the clinic supplies its final phone number, physical address, registration details, and staff names.
